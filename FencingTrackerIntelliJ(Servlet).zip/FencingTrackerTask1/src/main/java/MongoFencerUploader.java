//name: Simeon Olawale-Apanpa
//andrewID: solawale

import com.mongodb.client.*;
import org.bson.Document;

import java.util.Arrays;

public class MongoFencerUploader {
    public static void main(String[] args) {
        String uri = "mongodb+srv://solawale:mouse789@cluster0.mafj8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase db = mongoClient.getDatabase("fencingDB");
            MongoCollection<Document> collection = db.getCollection("fencers");

            // Insert a fencer's ELO strength manually or from the Java Excel program
            Document fencerDoc = new Document("name", "Robby Tarchichi")
                    .append("strength", 1895)
                    .append("category", "Junior Men's Epee");

            collection.insertOne(fencerDoc);
            System.out.println("Data inserted.");

            // Read it back
            Document result = collection.find(new Document("name", "Robby Tarchichi")).first();
            System.out.println("Fetched from DB: " + result.toJson());
        }
    }
}
