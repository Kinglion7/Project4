//name: Simeon Olawale-Apanpa
//andrewID: solawale

import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

//import javax.servlet.*;
//import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;

public class FencerInfoServlet extends HttpServlet {
    private MongoClient mongoClient;
    private MongoDatabase db;

    @Override
    public void init() throws ServletException {
        String uri = "mongodb+srv://solawale:mouse789@cluster0.mafj8.mongodb.net/?retryWrites=true&w=majority";
        mongoClient = MongoClients.create(uri);
        db = mongoClient.getDatabase("fencingDB");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fencerName = request.getParameter("name");
        String model = request.getParameter("model"); // From Android device

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        if (fencerName == null || fencerName.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write("{\"error\": \"Missing fencer name\"}");
            return;
        }

        MongoCollection<Document> fencerColl = db.getCollection("fencers");
        Document queryResult = fencerColl.find(Filters.eq("name", fencerName)).first();

        if (queryResult == null) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.write("{\"error\": \"Fencer not found\"}");
            return;
        }

        JSONObject json = new JSONObject();
        json.put("name", queryResult.getString("name"));
        json.put("timestamp", queryResult.getDate("timestamp"));

        // Convert ratings list to JSON
        JSONArray ratingsArray = new JSONArray();
        for (Document d : (Iterable<Document>) queryResult.get("ratings", Iterable.class)) {
            JSONObject entry = new JSONObject();
            entry.put("weapon", d.getString("weapon"));
            entry.put("rating", d.getString("rating"));
            entry.put("date", d.getString("date"));
            ratingsArray.put(entry);
        }
        json.put("ratings", ratingsArray);
        out.write(json.toString());

        // Logging
        Document log = new Document("timestamp", new Date())
                .append("model", model)
                .append("fencerName", fencerName)
                .append("ratingsReturned", ratingsArray.length());
        db.getCollection("logs").insertOne(log);
    }

    @Override
    public void destroy() {
        mongoClient.close();
    }
}
