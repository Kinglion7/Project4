//name: Simeon Olawale-Apanpa
//andrewID: solawale

import com.mongodb.client.*;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Sorts;
import org.bson.Document;

import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.mongodb.client.model.Filters.*;

public class DashboardServlet extends HttpServlet {
    private MongoClient mongoClient;
    private MongoDatabase db;

    @Override
    public void init() throws ServletException {
        String uri = "mongodb+srv://solawale:mouse789@cluster0.mafj8.mongodb.net/?retryWrites=true&w=majority";
        mongoClient = MongoClients.create(uri);
        db = mongoClient.getDatabase("fencingDB");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        MongoCollection<Document> logs = db.getCollection("logs");
        MongoCollection<Document> fencers = db.getCollection("fencers");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        // Header
        out.println("<html><head><title>Fencer Dashboard</title></head><body>");
        out.println("<h1>Fencer Lookup Dashboard</h1>");

        // Total lookups
        long totalLookups = logs.countDocuments();
        out.println("<h2>Total Lookups: " + totalLookups + "</h2>");

        // Top 3 searched fencer names
        out.println("<h2>Top 3 Fencer Names</h2><ul>");
        List<Document> topFencers = logs.aggregate(Arrays.asList(
                Aggregates.group("$fencerName", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(3)
        )).into(new ArrayList<>());

        for (Document doc : topFencers) {
            out.println("<li>" + doc.getString("_id") + " (" + doc.getInteger("count") + " lookups)</li>");
        }
        out.println("</ul>");

        // Top 3 most recent ratings
        out.println("<h2>Top 3 Most Recent Ratings</h2><ul>");
        List<Document> recentRatings = fencers.find()
                .projection(new Document("name", 1).append("ratings", 1))
                .into(new ArrayList<>());

        List<Document> allRatings = new ArrayList<>();
        for (Document fencer : recentRatings) {
            List<Document> ratings = (List<Document>) fencer.get("ratings");
            if (ratings != null) {
                for (Document rating : ratings) {
                    rating.append("fencer", fencer.getString("name"));
                    allRatings.add(rating);
                }
            }
        }

        allRatings.sort((a, b) -> b.getString("date").compareTo(a.getString("date")));
        for (int i = 0; i < Math.min(3, allRatings.size()); i++) {
            Document r = allRatings.get(i);
            out.println("<li>" + r.getString("fencer") + ": " +
                    r.getString("weapon") + " - " +
                    r.getString("rating") + " on " +
                    r.getString("date") + "</li>");
        }
        out.println("</ul>");

        // Log Table
        out.println("<h2>Logs</h2><table border='1'><tr><th>Timestamp</th><th>Fencer Name</th><th>Model</th><th>Ratings Returned</th></tr>");
        for (Document doc : logs.find().sort(Sorts.descending("timestamp"))) {
            Date ts = doc.getDate("timestamp");
            String fencer = doc.getString("fencerName");
            String model = doc.getString("model");
            Integer count = doc.getInteger("ratingsReturned");

            out.println("<tr><td>" + sdf.format(ts) + "</td><td>" +
                    fencer + "</td><td>" +
                    model + "</td><td>" +
                    count + "</td></tr>");
        }
        out.println("</table>");

        out.println("</body></html>");
    }

    @Override
    public void destroy() {
        mongoClient.close();
    }
}
