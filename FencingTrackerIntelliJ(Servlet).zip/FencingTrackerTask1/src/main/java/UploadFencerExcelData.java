//name: Simeon Olawale-Apanpa
//andrewID: solawale

import com.mongodb.client.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bson.Document;

import java.io.*;
import java.util.*;

public class UploadFencerExcelData {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter fencer name: ");
        String fencerName = scanner.nextLine();

        // Step 1: Call Python script to generate the Excel file
        try {
            System.out.println("Running Python script to fetch fencer data...");
            Process p = new ProcessBuilder("python", "datapull.py", fencerName).inheritIO().start();
            p.waitFor();  // wait until it finishes
        } catch (Exception e) {
            System.err.println("Error running datapull.py: " + e.getMessage());
            return;
        }

        // Assume folder is created with fencerName and contains fencing_data.xlsx
        String folderName = fencerName.replaceAll("[^a-zA-Z0-9\\s]", "").trim();
        String excelPath = folderName + "/fencing_data.xlsx";

        File excelFile = new File(excelPath);
        if (!excelFile.exists()) {
            System.err.println("Excel file not found at: " + excelPath);
            return;
        }

        // Step 2: Read Excel and parse first sheet
        List<Document> ratings = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(excelFile);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet("Summary-Rating History");
            if (sheet == null) {
                System.err.println("Sheet 'Summary-Rating History' not found.");
                return;
            }
            System.out.println("Reading sheet: " + sheet.getSheetName());

            Row header = sheet.getRow(0);
            if (header == null || header.getPhysicalNumberOfCells() < 3) {
                System.err.println("First sheet does not contain expected columns.");
                return;
            }

            int weaponCol = 0, ratingCol = 1, dateCol = 2;

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue;

                String weapon = getStringCellValue(row.getCell(weaponCol));
                String rating = getStringCellValue(row.getCell(ratingCol));
                String date = getStringCellValue(row.getCell(dateCol));

                if (weapon != null && rating != null && date != null) {
                    Document entry = new Document("weapon", weapon)
                            .append("rating", rating)
                            .append("date", date);
                    ratings.add(entry);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to read Excel: " + e.getMessage());
            return;
        }

        if (ratings.isEmpty()) {
            System.out.println("No valid data found in first sheet.");
            return;
        }

        // Step 3: Upload to MongoDB
        String uri = "mongodb+srv://solawale:mouse789@cluster0.mafj8.mongodb.net/?retryWrites=true&w=majority";
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase db = mongoClient.getDatabase("fencingDB");
            MongoCollection<Document> collection = db.getCollection("fencers");

            Document fencerDoc = new Document("name", fencerName)
                    .append("ratings", ratings)
                    .append("timestamp", new Date());

            collection.insertOne(fencerDoc);
            System.out.println("Data inserted into MongoDB for fencer: " + fencerName);
        } catch (Exception e) {
            System.err.println("MongoDB error: " + e.getMessage());
        }
    }

    private static String getStringCellValue(Cell cell) {
        if (cell == null) return null;
        switch (cell.getCellType()) {
            case STRING: return cell.getStringCellValue().trim();
            case NUMERIC: return String.valueOf(cell.getNumericCellValue());
            default: return null;
        }
    }
}
