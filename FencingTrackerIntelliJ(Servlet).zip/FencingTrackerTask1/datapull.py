//name: Simeon Olawale-Apanpa
//andrewID: solawale

import os
import re
import requests
from bs4 import BeautifulSoup
import pandas as pd
import html

# --- Utility Functions ---

def sanitize_filename(name):
    # Remove characters not allowed in folder/file names
    return re.sub(r'[\\/*?:"<>|]', "", name)

def sanitize_sheet_name(name):
    # Remove invalid characters for Excel sheet names and truncate to 31 characters
    return re.sub(r'[\\/*?:"\[\]]', "-", name)[:31]

# --- Search and Download Functions ---

def search_fencer_by_post(fencer_name):
    """
    Sends a POST request to /search with JSON:
      { "query": fencer_name, "limit": 10 }
    Returns a tuple (fencer_page_url, fencer_name_found) if a match is found;
    otherwise (None, None).
    """
    search_url = "https://fencingtracker.com/search"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/90.0.4430.93 Safari/537.36",
        "Content-Type": "application/json"
    }
    data = {"query": fencer_name, "limit": 10}
    try:
        resp = requests.post(search_url, json=data, headers=headers, timeout=10)
        resp.raise_for_status()
    except Exception as e:
        print("Error performing POST search:", e)
        return None, None

    try:
        results = resp.json()
        if not results:
            print("No results found for:", fencer_name)
            return None, None

        # Pick the first match (you may refine this logic)
        first_match = results[0]
        usfa_id = first_match["usfa_id"]
        name_slug = first_match["name"]  # e.g., "Robby-Tarchichi"
        fencer_page_url = f"https://fencingtracker.com/p/{usfa_id}/{name_slug}"
        # Also return a human-readable name (replace hyphens with spaces)
        fencer_name_found = first_match["name"].replace('-', ' ')
        return fencer_page_url, fencer_name_found
    except Exception as e:
        print("Error parsing JSON response:", e)
        return None, None

def download_page(url):
    """
    Downloads a page's HTML content using a GET request.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/90.0.4430.93 Safari/537.36"
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        print(f"Downloaded page from {url}")
        return response.text
    except Exception as e:
        print("Failed to download page:", e)
        return None

# --- HTML Processing Functions ---

def process_generic_html(html_content):
    """
    Processes HTML content (reconstructing from code-view if needed) and extracts tables 
    following each <h3> header.
    Returns a dictionary {section_name: DataFrame, ...}.
    """
    soup_outer = BeautifulSoup(html_content, "html.parser")
    line_contents = soup_outer.find_all("td", class_="line-content")
    if line_contents:
        reconstructed_html = "\n".join(td.get_text() for td in line_contents)
        reconstructed_html = html.unescape(reconstructed_html)
        soup = BeautifulSoup(reconstructed_html, "html.parser")
    else:
        soup = soup_outer

    h3_tags = soup.find_all("h3")
    tables_dict = {}
    for header in h3_tags:
        section_name = header.get_text(strip=True)
        table = header.find_next("table")
        if table:
            header_cols = [th.get_text(strip=True) for th in table.find_all("th")]
            rows = table.find_all("tr")[1:]  # skip header row
            table_data = []
            for row in rows:
                cols = row.find_all("td")
                col_text = [col.get_text(strip=True) for col in cols]
                if col_text:
                    table_data.append(col_text)
            if table_data and header_cols:
                try:
                    df = pd.DataFrame(table_data, columns=header_cols)
                    tables_dict[section_name] = df
                    print(f"Extracted table for section: {section_name}")
                except Exception as e:
                    print(f"Error processing section '{section_name}':", e)
        else:
            print(f"No table found after header: {section_name}")
    return tables_dict

def process_competition_history(soup):
    """
    Processes the competition history part of the history page.
    Assumes the competition history section starts with an <h3> header containing 
    "Competition History" and then contains multiple competitions marked with <h4>, <h5>, and <h6> for extra details.
    Returns a DataFrame containing the concatenated competition history with additional columns:
      "Tournament Name", "Event", "Classification", "Date", "Placement", "Entries".
    """
    history_header = soup.find("h3", string=lambda x: x and "Competition History" in x)
    if not history_header:
        print("No Competition History header found.")
        return None
    else:
        print("Found Competition History header:", history_header.get_text(strip=True))
    
    competition_dfs = []
    # Initialize variables to hold details for the current competition block.
    current_competition = None  # from <h4>
    current_event = None        # from <h5> <a> text
    current_classification = None  # from <h5> (inside parentheses)
    current_date = None            # from <h5> (after comma)
    current_placement = None       # from <h6> ("Place X of Y")
    current_entries = None         # from <h6> ("of Y")

    # Iterate over elements following the Competition History header until the next <h3>
    for elem in history_header.find_all_next():
        if elem.name == "h3" and elem != history_header:
            break

        # h4: tournament name
        if elem.name == "h4":
            current_competition = elem.get_text(strip=True)
            #print("Found tournament name:", current_competition)
        
        # h5: event, classification, date
        elif elem.name == "h5":
            a_tag = elem.find("a")
            current_event = a_tag.get_text(strip=True) if a_tag else None
            h5_text = elem.get_text(separator=" ", strip=True)
            classification_match = re.search(r"\((.*?)\)", h5_text)
            current_classification = classification_match.group(1) if classification_match else None
            parts = h5_text.split(",")
            if len(parts) >= 2:
                current_date = parts[-1].strip()
            else:
                current_date = None
            #print("Found event:", current_event, "| Classification:", current_classification, "| Date:", current_date)
        
        # h6: placement and entries
        elif elem.name == "h6":
            h6_text = elem.get_text(separator=" ", strip=True)
            placement_match = re.search(r"Place\s+(\d+)\s+of\s+(\d+)", h6_text)
            if placement_match:
                current_placement = placement_match.group(1)
                current_entries = placement_match.group(2)
            else:
                current_placement = None
                current_entries = None
            #print("Found placement:", current_placement, "| Entries:", current_entries)
        
        # Process the table that follows and append the header details.
        elif elem.name == "table":
            header_cols = [th.get_text(strip=True) for th in elem.find_all("th")]
            if not header_cols:
                first_row = elem.find("tr")
                if first_row:
                    header_cols = [td.get_text(strip=True) for td in first_row.find_all("td")]
                    rows = elem.find_all("tr")[1:]
                else:
                    rows = elem.find_all("tr")
            else:
                rows = elem.find_all("tr")[1:]
            table_data = []
            for row in rows:
                cols = row.find_all("td")
                col_text = [col.get_text(strip=True) for col in cols]
                if col_text:
                    # Append the extra details from the header block.
                    col_text.extend([
                        current_competition if current_competition else "",
                        current_event if current_event else "",
                        current_classification if current_classification else "",
                        current_date if current_date else "",
                        current_placement if current_placement else "",
                        current_entries if current_entries else ""
                    ])
                    table_data.append(col_text)
            if table_data and header_cols:
                header_cols.extend(["Tournament Name", "Event", "Classification", "Date", "Placement", "Entries"])
                try:
                    df = pd.DataFrame(table_data, columns=header_cols)
                    competition_dfs.append(df)
                    #print(f"Extracted competition table for: {current_competition} | {current_event}")
                except Exception as e:
                    print(f"Error processing competition table for {current_competition}: {e}")
    if competition_dfs:
        final_df = pd.concat(competition_dfs, ignore_index=True)
        return final_df
    else:
        return None

def process_history_section(soup, section_title):
    """
    Processes a history section given its h3 title (e.g., "Win/Loss Statistics").
    Returns a DataFrame for that section or None if not found.
    """
    section_header = soup.find("h3", string=lambda x: x and section_title.lower() in x.lower())
    if not section_header:
        print(f"Section '{section_title}' not found.")
        return None
    table = section_header.find_next("table")
    if not table:
        print(f"No table found for section '{section_title}'.")
        return None
    header_cols = [th.get_text(strip=True) for th in table.find_all("th")]
    rows = table.find_all("tr")[1:]  # skip header row
    table_data = []
    for row in rows:
        cols = row.find_all("td")
        col_text = [col.get_text(strip=True) for col in cols]
        if col_text:
            table_data.append(col_text)
    if table_data and header_cols:
        try:
            df = pd.DataFrame(table_data, columns=header_cols)
            print(f"Extracted table for section: {section_title}")
            return df
        except Exception as e:
            print(f"Error processing section '{section_title}':", e)
            return None
    else:
        print(f"No data found for section '{section_title}'.")
        return None

def process_history_page(html_content):
    """
    Processes the History page HTML and returns a dictionary of DataFrames for:
      - Win/Loss Statistics
      - Scores
      - Bouts with Time Expired
      - Events
      - Competition History (with extra details)
    """
    soup_outer = BeautifulSoup(html_content, "html.parser")
    line_contents = soup_outer.find_all("td", class_="line-content")
    if line_contents:
        reconstructed_html = "\n".join(td.get_text() for td in line_contents)
        reconstructed_html = html.unescape(reconstructed_html)
        soup = BeautifulSoup(reconstructed_html, "html.parser")
    else:
        soup = soup_outer

    sections = {}
    # Process the separate sections by h3 titles.
    for sec in ["Win/Loss Statistics", "Scores", "Bouts with Time Expired", "Events"]:
        df = process_history_section(soup, sec)
        if df is not None:
            sections[sec] = df

    # Process competition history separately with extra details.
    comp_hist_df = process_competition_history(soup)
    if comp_hist_df is not None:
        sections["Competition History"] = comp_hist_df

    return sections

# --- Main Workflow ---

if __name__ == "__main__":
    fencer_name_input = input("Enter the fencer's name: ")
    
    # 1. Search via POST to get the fencer page URL and the fencer's display name.
    fencer_url, fencer_name_found = search_fencer_by_post(fencer_name_input)
    if not fencer_url:
        print("No matching fencer found; folder will not be created.")
        exit()
    print("Found fencer URL:", fencer_url)
    
    # 2. Create (or reuse) a folder for the fencer.
    folder_name = sanitize_filename(fencer_name_found)
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
        print(f"Created folder: {folder_name}")
    else:
        print(f"Folder already exists: {folder_name}")
    
    # 3. Download the pages: Summary (main), History, and Strength.
    summary_html = download_page(fencer_url)
    history_html = download_page(fencer_url + "/history")
    strength_html = download_page(fencer_url + "/strength")
    
    # 4. Process each page.
    summary_data = process_generic_html(summary_html) if summary_html else {}
    history_data_sections = process_history_page(history_html) if history_html else {}
    strength_data = process_generic_html(strength_html) if strength_html else {}
    
    # 5. Write all extracted data to a single Excel file with separate sheets.
    output_excel = os.path.join(folder_name, "fencing_data.xlsx")
    with pd.ExcelWriter(output_excel, engine="openpyxl") as writer:
        # Summary sheets.
        if summary_data:
            for section, df in summary_data.items():
                sheet_name = sanitize_sheet_name("Summary-" + section)
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            print("No summary data found.")
        # History sheets.
        if history_data_sections:
            for section, df in history_data_sections.items():
                sheet_name = sanitize_sheet_name("History-" + section)
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            print("No history data found.")
        # Strength sheets.
        if strength_data:
            for section, df in strength_data.items():
                sheet_name = sanitize_sheet_name("Strength-" + section)
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            print("No strength data found.")
    print(f"All data successfully saved in '{output_excel}'")
